package com.example.movieboxbeta.db;

public interface Constants {

    String DB_NAME = "FavMovies.db";
    String DB_TABLE = "Movie";

}